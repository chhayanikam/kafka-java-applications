package com.pradeep.kafka.producer;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
public class SimpleProducer {
  
   public static void main(String[] args) throws Exception{
           
      String topicName = "c-topic";
	  String key = "India";
	  String value = "Sachin Chinchole  ";
      
      Properties props = new Properties();
    // props.put("bootstrap.servers", "localhost:9092,localhost:9094");
      props.put("bootstrap.servers", "localhost:9092");
      
      props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");         
      props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	        
      //Producer<String, String> producer = new KafkaProducer <>(props);
      
      Producer<String, String> producer = new KafkaProducer <>(props);
      
	  
		  
	  	  
	  for(int i=1;i<=10;i++)
	  {
		ProducerRecord<String, String> record = new ProducerRecord<>(topicName,key+""+i,value+""+i);
		producer.send(record);	       
	  }
	  producer.close();
	  
	  System.out.println("SimpleProducer Completed the message sending");
   }
}